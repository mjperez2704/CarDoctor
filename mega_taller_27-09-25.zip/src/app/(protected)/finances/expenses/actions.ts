// src/app/(protected)/finances/expenses/actions.ts
"use server";

import pool from '@/lib/db';
import type { RowDataPacket } from 'mysql2';

// Definimos la estructura de los datos para la tabla de gastos
export interface Expense extends RowDataPacket {
    id: number;
    fecha: string;
    categoria: string;
    descripcion: string | null;
    monto: number;
    empleado_id: number;
    empleado_nombre: string; // Nombre del empleado que realizó el gasto
    estado: "PENDIENTE" | "APROBADO" | "RECHAZADO";
}

// Acción para obtener todos los gastos
export async function getExpenses(): Promise<Expense[]> {
    let db;
    try {
        db = await pool.getConnection();
        const [rows] = await db.query<Expense[]>(`
            SELECT 
                g.id,
                g.fecha,
                g.categoria,
                g.descripcion,
                g.monto,
                g.empleado_id,
                CONCAT(e.nombre, ' ', e.apellido_p) as empleado_nombre,
                g.estado
            FROM gastos g
            JOIN empleados e ON g.empleado_id = e.id
            ORDER BY g.fecha DESC;
        `);
        return rows;
    } catch (error) {
        console.error("Error fetching expenses:", error);
        return [];
    } finally {
        if (db) db.release();
    }
}
