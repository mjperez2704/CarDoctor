// src/lib/db.ts
import mysql from 'mysql2/promise';

// Configura los datos de conexión con tus credenciales de MariaDB
const pool = mysql.createPool({
    host: 'localhost', // O la IP de tu servidor de base de datos
    user: 'mega_taller', // Tu usuario de la base de datos
    password: 'mega_taller', // Tu contraseña
    database: 'taller_mecanico',
    port: 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

export default pool;
