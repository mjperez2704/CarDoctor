import { config } from 'dotenv';
config();

import '@/ai/flows/stock-level-suggestions.ts';