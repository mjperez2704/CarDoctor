import { Sales } from "@/components/sales";

export default function SalesPage() {
  return (
    <Sales />
  );
}
